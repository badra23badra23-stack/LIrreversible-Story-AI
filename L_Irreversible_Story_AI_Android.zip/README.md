# L'Irréversible Story AI

Projet Android prêt à compiler.

## Compilation
Le workflow GitHub Actions inclus dans `.github/workflows/build-apk.yml` compile automatiquement `app-debug.apk`.

## Version actuelle
- Android 7.0+ (minSdk 24)
- Création locale de petites histoires
- Choix de thèmes
- Partage Android vers Facebook, WhatsApp, etc.

## Prochaine version
- vraie IA via API
- génération d'images
- historique
- connexion officielle Meta/Facebook
- publication sur une Page avec autorisation

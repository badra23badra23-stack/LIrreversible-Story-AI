package com.irreversible.storyai

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = 24
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "🤖 L’Irréversible Story AI"
            textSize = 26f
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Crée une petite histoire et prépare ta publication."
            textSize = 15f
        }
        root.addView(subtitle)

        val theme = Spinner(this)
        val themes = arrayOf("Motivation", "Persévérance", "Amour", "Drame", "Réussite", "Morale", "Humour")
        theme.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themes)
        root.addView(theme)

        val idea = EditText(this).apply {
            hint = "Ton idée (facultatif)"
            minLines = 3
            gravity = 48
        }
        root.addView(idea)

        val create = Button(this).apply { text = "✨ Créer l’histoire" }
        root.addView(create)

        val result = EditText(this).apply {
            hint = "Ton histoire apparaîtra ici..."
            minLines = 12
            gravity = 48
            isVerticalScrollBarEnabled = true
        }
        root.addView(result)

        val share = Button(this).apply { text = "📤 Partager sur Facebook / WhatsApp" }
        root.addView(share)

        create.setOnClickListener {
            val t = theme.selectedItem.toString()
            val i = idea.text.toString().trim()
            val opening = when(t) {
                "Motivation" -> "Tout le monde lui disait d’abandonner. Pourtant, il décida d’essayer encore une fois."
                "Persévérance" -> "Chaque matin, il recommençait malgré les échecs."
                "Amour" -> "Elle pensait que leur histoire était terminée."
                "Drame" -> "Ce jour-là, il reçut une nouvelle qui allait changer sa vie."
                "Réussite" -> "Personne ne croyait qu’il y arriverait."
                "Morale" -> "Un vieil homme lui posa une question très simple."
                else -> "Il pensait passer une journée ordinaire. Il était loin d’imaginer ce qui allait arriver."
            }
            val extra = if (i.isNotEmpty()) "\n\nSon idée était simple : $i." else ""
            val story = """$opening$extra

Au début, rien ne semblait fonctionner. Il doutait de lui-même et plusieurs personnes lui conseillèrent de prendre un autre chemin.

Mais il continua. Il apprit de ses erreurs, travailla encore et saisit une petite occasion quand elle se présenta.

Ce n’était pas magique. C’était simplement le début.

Quelques mois plus tard, il comprit une chose : une grande réussite peut commencer par une petite décision.

💭 Et toi, aurais-tu continué à sa place ?

#Motivation #Histoire #Persévérance #LIrreversible"""
            result.setText(story)
        }

        share.setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, result.text.toString())
            }
            startActivity(Intent.createChooser(send, "Partager avec…"))
        }

        setContentView(root)
    }
}
